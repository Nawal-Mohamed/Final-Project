export const BestOfferFooter = [
    {
        id: 1,
        heading: "Best prices & offers",
        description: "Orders $50 or more ",
        img: "https://nest-frontend-v6.vercel.app/assets/imgs/theme/icons/icon-1.svg",
    },
    {
        id: 2,
        heading: "Free delivery",
        description: "24/7 amazing services",
        img: "https://nest-frontend-v6.vercel.app/assets/imgs/theme/icons/icon-2.svg",
    },
    {
        id: 3,
        heading: "Great daily deal",
        description: "When you sign up ",
        img: "https://nest-frontend-v6.vercel.app/assets/imgs/theme/icons/icon-3.svg",
    },
    {
        id: 4,
        heading: "Wide assortment",
        description: "Mega Discounts",
        img: "https://nest-frontend-v6.vercel.app/assets/imgs/theme/icons/icon-4.svg",
    },
    {
        id: 5,
        heading: "Easy returns",
        description: "Within 30 days",
        img: "https://nest-frontend-v6.vercel.app/assets/imgs/theme/icons/icon-5.svg",
    },
];
