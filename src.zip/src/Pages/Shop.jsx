import React from 'react'
import Navbar from '../Common component/Navbar'

export default function Shop() {
  return (
    <>
         <Navbar/>
    </>
  )
}
