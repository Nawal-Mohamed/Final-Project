import React from 'react'
import Navbar from '../Common component/Navbar'

export default function About() {
  return (
    <>
         <Navbar />
    </>
  )
}
